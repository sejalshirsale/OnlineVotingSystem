<?php

$connect = mysqli_connect("localhost","root","","voting") or die("Connection failed");

?>