# Online-Voting-System
A Web-based voting system that allows to manage elections easily and securely. This can be used for casting votes for any general purposes.
